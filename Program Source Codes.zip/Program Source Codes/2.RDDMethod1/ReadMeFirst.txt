Sample output from 1.LoadData is already placed in input folder for 2.RDDMethod

OutPut Details:
1st RDD :- BookValue

2nd RDD :- UserList

3rd RDD :- BooksOfUser

4th RDD :- Final

Please delete Output folder if you wish to run again. 

Execution Command
spark-submit --class bigdata.project.RecommendationSystem --master local[2]  /ProjectJAVA/2.RDDMethod1/project-0.0.1-SNAPSHOT.jar  /ProjectJAVA/2.RDDMethod1/input/Data.txt /ProjectJAVA/2.RDDMethod1/output A7767825ZOG1L
