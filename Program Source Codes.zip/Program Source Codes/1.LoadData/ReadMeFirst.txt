As Input File is Very Large, so we could not attach it with Artifacts.
To download input file which is in JSON format (Plese put downloaded file in input Folder: Books_5.json):
http://jmcauley.ucsd.edu/data/amazon/


Load Data Run Command
spark-submit --class amazonbk.bk.LoadData --master local[2]  /ProjectJAVA/1.LoadData/bk-0.0.1-SNAPSHOT.jar  /ProjectJAVA/1.LoadData/input/Books_5.json /ProjectJAVA/1.LoadData/output
