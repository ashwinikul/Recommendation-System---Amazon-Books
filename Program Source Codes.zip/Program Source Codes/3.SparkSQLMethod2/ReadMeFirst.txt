Sample output from 1.LoadData is already placed in input folder for 3.SparkSQLMethod2


OutPut Details:
1st Query :- BookValue

2nd Query :- UserList

3rd Query :- BooksOfUser

4th Query :- Top10Books

Please delete Output folder if you wish to run again. 


Load Data Run Command
spark-submit --class amazon.amazon.Recomandation_System --master local[2]  /ProjectJAVA/3.SparkSQLMethod2/amazon-0.0.1-SNAPSHOT.jar  /ProjectJAVA/3.SparkSQLMethod2/input/Data.txt /ProjectJAVA/3.SparkSQLMethod2/output A1BM81XB4QHOA3
